<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registation extends Model
{
    protected $fillable = ['nama', 'email', 'pesan'];
}
