@extends('components.master')
@section('title', 'Resisdence')

@section('content')
    <div class="container">
        <img src="{{asset('image/R.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/S.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/T.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/U.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/V.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/W.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/X.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/Y.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/Z.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/Z1.jpg')}}" class="d-block w-100 mb-5">
        <img src="{{asset('image/Z2.jpg')}}" class="d-block w-100 mb-5">
        <br>
        <br>
        <br>
    </div>
@endsection