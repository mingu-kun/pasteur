
<?php $__env->startSection('title', 'Registration'); ?>
<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
<div class="alert alert-success">
    <?php echo e(session()->get('message')); ?>

</div>
<?php endif; ?>
<div class="container pt-5 pb-5 bg-light rounded" style="margin-bottom: 90px"  >
    <div class="row ">
        <div class="col-6 text-center mt-5">
            <img src="<?php echo e(asset('image/logo-gateway-3@2x.png')); ?>" height="300" width="370">
        </div>
        <div class="col-6 mt-5 ">
            <h3 class="text-center mb-4">Isi Formulir Ini Dengan Lengkap</h3>
            <form method="POST" action="<?php echo e(route('registration')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Nama Lengkap" name="nama">
                    <input type="text" class="form-control mt-2 mb-2" id="formGroupExampleInput2" placeholder="No Hp Aktif" name="telp">
                    <input type="text" class="form-control mt-2 mb-2" id="formGroupExampleInput2" placeholder="Email" name="email">
                    <input type="text" class="form-control" id="inputAddress" placeholder="Alamat lengkap" name="alamat">
                    <button class="btn btn-info btn-sm mt-3" type="submit">Daftar</button>
                </div>
                
                </form>
        </div>
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/pasteurgateway.com/httpdocs/resources/views/registration.blade.php ENDPATH**/ ?>