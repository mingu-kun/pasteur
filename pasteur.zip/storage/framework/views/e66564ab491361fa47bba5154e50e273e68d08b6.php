
<?php $__env->startSection('title', 'Resisdence'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <img src="<?php echo e(asset('image/R.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/S.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/T.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/U.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/V.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/W.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/X.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/Y.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/Z.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/Z1.jpg')); ?>" class="d-block w-100 mb-5">
        <img src="<?php echo e(asset('image/Z2.jpg')); ?>" class="d-block w-100 mb-5">
        <br>
        <br>
        <br>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/pasteurgateway.com/httpdocs/resources/views/price.blade.php ENDPATH**/ ?>